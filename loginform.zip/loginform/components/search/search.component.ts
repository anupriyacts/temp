import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

 
  searchForm:FormGroup;
  constructor(private router:Router) {
    this.searchForm = new FormGroup({
      source : new FormControl("", [
        Validators.required,
       
      ]),
      destination : new FormControl("", [
        Validators.required,
      ]),
      departdate : new FormControl("", [
        Validators.required,
      ]),
      returndate : new FormControl("", [
        Validators.required,
      ])
   });
  }

  ngOnInit(): void {
  }
  getFlights()
  {
    this.router.navigate(["booking"]);
  }
}
