import { Component, OnInit } from '@angular/core';
import { Flight } from '../model/flight';
import { RetriveFlightService } from '../services/retriveAllFlights-service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-retrive-all-flights',
  templateUrl: './retrive-all-flights.component.html',
  styleUrls: ['./retrive-all-flights.component.scss']
})
export class RetriveAllFlightsComponent implements OnInit {
 

  ngOnInit(){
   
  }
  

}
