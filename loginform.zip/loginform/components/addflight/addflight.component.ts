import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbCalendar, NgbDate, NgbDateAdapter, NgbDateNativeAdapter, NgbDatepicker, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-addflight',
  templateUrl: './addflight.component.html',
  styleUrls: ['./addflight.component.scss']
})
export class AddflightComponent implements OnInit {

  addflightform:FormGroup;

  constructor(private router:Router) {

    this.addflightform = new FormGroup({
      airlineName : new FormControl("", [
        Validators.required,
        
      ]),
      flightName : new FormControl("", [
        Validators.required,
      ]),
      source : new FormControl("", [
        Validators.required,
      ]),
      destination : new FormControl("", [
        Validators.required,
      ]),
      departdate : new FormControl("", [
        Validators.required,
      ]),
      departtime : new FormControl("", [
        Validators.required,
      ]),
   });

 


 
  }

  
  

  

  ngOnInit(): void {
  }
  getLogin()
  {
    console.log(this.addflightform.value)
    alert("wow");
    this.router.navigate(["adminpage"]);
  }

  

}
