import { Time } from "@angular/common";

export class SearchFlightParams{
    constructor(
  
    public source:string, 
    public destination:string,
    public departureDate:Date,
    public arrivalDate:Date
	){}
   
}