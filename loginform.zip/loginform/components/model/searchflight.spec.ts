import { Searchflight } from './searchflight';

describe('Searchflight', () => {
  it('should create an instance', () => {
    expect(new Searchflight()).toBeTruthy();
  });
});
