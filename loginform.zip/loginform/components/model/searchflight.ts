export class Searchflight {
    source?:string;
    destination?:string;
    departdate?:Date;
    returndate?:Date
}
