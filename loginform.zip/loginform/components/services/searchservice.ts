import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders , HttpParams } from '@angular/common/http';
import { Searchflight } from '../model/searchflight';
import { SearchFlightParams } from '../model/searchflightmodel';
import { Observable } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
//import { url } from 'inspector';
 
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 
@Injectable({
    providedIn: 'root'
  })
export class searchservice {
    private searchUrl = 'http://localhost:9050/searchFlights/';
    constructor(private httpClient:HttpClient) {}
    
 /*  msg: SearchFlightParams ={source:null, destination:null,departDate:null,returnDate:null};
  constructor(private http:HttpClient) {}
 
  //private userUrl = 'http://localhost:8080/user-portal/user';
        private userUrl = 'http://localhost:9050/searchFlights/';
 
    public createUser(msg) {
    return this.http.post<SearchFlightParams>(this.userUrl, msg);
  } */
  getFlights(searchinputs?: Searchflight): Observable<Object>{
  return this.httpClient.post<Object>(`${this.searchUrl}`,searchinputs);
  }
  deleteBooking(pnr: number): Observable<any> {
    //return this.http.delete(`${this.Url}/searchFlights/booking/cancel/pnr`, { responseType: 'text' });
    console.log('Inside');
    let url : string = "http://localhost:9050/searchFlights/booking/cancel/"+pnr;
    console.log(url);
    return this.httpClient.delete<String>(url).pipe
    (catchError(this.handleError));
  }
  private handleError(err:HttpErrorResponse){
    let errString : string ='';
    console.log(err);
    return errString;
  }
  
}