import { Component, OnInit } from '@angular/core';
import { Searchflight } from '../model/searchflight';
import { searchservice } from '../services/searchservice';

@Component({
  selector: 'app-searchflight',
  templateUrl: './searchflight.component.html',
  styleUrls: ['./searchflight.component.scss']
})
export class SearchflightComponent implements OnInit {

  searchparams: Searchflight= new Searchflight(); 
  constructor(private service:searchservice) { }

  ngOnInit(): void {
  }

  getflight(){
    console.log(this.searchparams);
    this.service.getFlights(this.searchparams).subscribe();
  }
}
