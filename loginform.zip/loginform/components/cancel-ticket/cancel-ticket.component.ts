import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

import { searchservice } from '../services/searchservice';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.scss']
})
export class CancelTicketComponent implements OnInit {

  pnr!: number;
  constructor(private service:searchservice){}

ngOnInit(): void {
}
cancelTicket(){
  console.log(this.pnr);
  this.service.deleteBooking(this.pnr);
}
}