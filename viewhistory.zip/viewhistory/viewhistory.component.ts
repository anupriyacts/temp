import { Component, OnInit } from '@angular/core';
import { searchservice } from '../services/searchservice';
import { TicketHistory } from '../model/ticket-history';

@Component({
  selector: 'app-viewhistory',
  templateUrl: './viewhistory.component.html',
  styleUrls: ['./viewhistory.component.scss']
})
export class ViewhistoryComponent implements OnInit {

  pnr!: number;
  viewhistory: any = [];
  constructor(private service:searchservice){}

ngOnInit(): void {
}

viewBookingHistory(){
  console.log(this.pnr);
  //this.service.deleteBooking(this.pnr);
  this.service.viewBookingHistory(this.pnr)
  .subscribe(
    (data:any) =>{
      this.viewhistory=data;
      console.log(this.viewhistory);
    }
  )
}
}
